<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('manual_payment_methods', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // e.g., Bkash Personal, Nagad Merchant, Dutch Bangla Bank
            $table->string('account_number');
            $table->text('instruction')->nullable(); // Instructions like "Send Money to this number..."
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('manual_payment_methods');
    }
};