<?php

namespace App\Services\Sms\Drivers;

use App\Models\SmsProvider;
use App\Services\Sms\Contracts\SmsProviderInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

class OnecodesoftDriver implements SmsProviderInterface
{
    protected SmsProvider $provider;
    protected string $baseUrl;
    protected ?string $apiToken;
    protected bool $isSandbox;

    public function __construct(?SmsProvider $provider = null)
    {
        $this->provider = $provider ?? SmsProvider::where('driver', 'onecodesoft')
            ->where('is_active', true)
            ->first() ?? new SmsProvider();

        $this->baseUrl = rtrim($this->provider->base_url ?: 'https://api.onecodesoft.com/api', '/');
        $this->apiToken = $this->provider->decrypted_token;
        $this->isSandbox = (bool) $this->provider->sandbox_mode;
    }

    /**
     * Standard HTTP client configured with bearer token and timeouts
     */
    protected function client()
    {
        return Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiToken,
            'Accept'        => 'application/json',
            'Content-Type'  => 'application/json',
        ])->timeout(20);
    }

    /**
     * Format Bangladeshi phone numbers to international standard 8801XXXXXXXXX
     */
    public function formatNumber(string $number): string
    {
        $clean = preg_replace('/[^0-9]/', '', $number);

        if (str_starts_with($clean, '01') && strlen($clean) === 11) {
            return '88' . $clean;
        }

        if (str_starts_with($clean, '1') && strlen($clean) === 10) {
            return '880' . $clean;
        }

        return $clean;
    }

    /**
     * Send single transactional or notification SMS
     */
    public function sendSingle(string $number, string $message, ?string $senderId = null): array
    {
        $formattedNumber = $this->formatNumber($number);
        $resolvedSenderId = $senderId ?: $this->provider->sender_id;

        if ($this->isSandbox) {
            return [
                'status'     => true,
                'message'    => '[SANDBOX] Message simulated successfully.',
                'message_id' => 'SANDBOX-' . uniqid(),
                'data'       => [
                    'recipient' => $formattedNumber,
                    'text'      => $message,
                    'sender_id' => $resolvedSenderId,
                    'sandbox'   => true,
                ],
            ];
        }

        try {
            $response = $this->client()->post("{$this->baseUrl}/v3/sms/send", array_filter([
                'number'    => $formattedNumber,
                'sms'       => $message,
                'sender_id' => $resolvedSenderId,
            ]));

            $result = $response->json() ?? [];

            if ($response->successful() && ($result['status'] ?? false || $result['success'] ?? false || ($result['code'] ?? null) === 200)) {
                return [
                    'status'     => true,
                    'message'    => $result['message'] ?? 'SMS sent successfully.',
                    'message_id' => $result['message_id'] ?? $result['data']['message_id'] ?? null,
                    'data'       => $result,
                ];
            }

            return [
                'status'  => false,
                'message' => $result['message'] ?? 'Failed to send SMS via Onecodesoft.',
                'data'    => $result,
            ];
        } catch (Exception $e) {
            Log::error('OnecodesoftDriver sendSingle Exception: ' . $e->getMessage());

            return [
                'status'  => false,
                'message' => 'Connection error: ' . $e->getMessage(),
                'data'    => null,
            ];
        }
    }

    /**
     * Send bulk personalized messages in a single batch
     */
    public function sendBulk(array $messageParameters, ?string $senderId = null): array
    {
        $resolvedSenderId = $senderId ?: $this->provider->sender_id;

        $normalizedBatch = array_map(function ($item) {
            return [
                'Number' => $this->formatNumber($item['Number'] ?? $item['number'] ?? ''),
                'Text'   => $item['Text'] ?? $item['text'] ?? $item['message'] ?? '',
            ];
        }, $messageParameters);

        if ($this->isSandbox) {
            return [
                'status'     => true,
                'message'    => '[SANDBOX] Bulk batch of ' . count($normalizedBatch) . ' simulated successfully.',
                'message_id' => 'SANDBOX-BULK-' . uniqid(),
                'data'       => $normalizedBatch,
            ];
        }

        try {
            $response = $this->client()->post("{$this->baseUrl}/v3/sms/send-bulk", array_filter([
                'messages'  => $normalizedBatch,
                'sender_id' => $resolvedSenderId,
            ]));

            $result = $response->json() ?? [];

            if ($response->successful()) {
                return [
                    'status'     => true,
                    'message'    => $result['message'] ?? 'Bulk batch processed.',
                    'message_id' => $result['batch_id'] ?? null,
                    'data'       => $result,
                ];
            }

            return [
                'status'  => false,
                'message' => $result['message'] ?? 'Bulk dispatch failed.',
                'data'    => $result,
            ];
        } catch (Exception $e) {
            Log::error('OnecodesoftDriver sendBulk Exception: ' . $e->getMessage());

            return [
                'status'  => false,
                'message' => 'Batch connection error: ' . $e->getMessage(),
                'data'    => null,
            ];
        }
    }

    /**
     * Check gateway balance and update local provider cache
     */
    public function checkBalance(): array
    {
        if ($this->isSandbox) {
            return [
                'status'        => true,
                'balance'       => 1000.00,
                'estimated_sms' => 2857,
                'currency'      => 'BDT',
            ];
        }

        try {
            $response = $this->client()->get("{$this->baseUrl}/v3/balance");
            $result = $response->json() ?? [];

            if ($response->successful()) {
                $balance = (float) ($result['balance'] ?? $result['data']['balance'] ?? 0.00);
                $estimatedSms = (int) ($result['remaining_sms'] ?? $result['data']['remaining_sms'] ?? 0);

                if ($this->provider->exists) {
                    $this->provider->update([
                        'balance'                => $balance,
                        'estimated_sms'          => $estimatedSms,
                        'last_balance_synced_at' => now(),
                        'last_connected_at'      => now(),
                    ]);
                }

                return [
                    'status'        => true,
                    'balance'       => $balance,
                    'estimated_sms' => $estimatedSms,
                    'currency'      => $result['currency'] ?? 'BDT',
                    'data'          => $result,
                ];
            }

            return [
                'status'  => false,
                'message' => $result['message'] ?? 'Unable to fetch balance.',
                'data'    => $result,
            ];
        } catch (Exception $e) {
            Log::error('OnecodesoftDriver checkBalance Exception: ' . $e->getMessage());

            return [
                'status'  => false,
                'message' => 'Balance query failed: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Delivery status inquiry
     */
    public function checkDeliveryStatus(string $messageId): array
    {
        if (str_starts_with($messageId, 'SANDBOX-')) {
            return [
                'status'          => true,
                'delivery_status' => 'delivered',
                'message_id'      => $messageId,
            ];
        }

        try {
            $response = $this->client()->get("{$this->baseUrl}/v3/sms/status/{$messageId}");
            $result = $response->json() ?? [];

            if ($response->successful()) {
                return [
                    'status'          => true,
                    'delivery_status' => $result['status'] ?? 'sent',
                    'data'            => $result,
                ];
            }

            return [
                'status'  => false,
                'message' => $result['message'] ?? 'Status check failed.',
                'data'    => $result,
            ];
        } catch (Exception $e) {
            return [
                'status'  => false,
                'message' => 'Status error: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Onecodesoft Managed Identity OTP Request
     */
    public function requestIdentityOtp(string $number): array
    {
        $formattedNumber = $this->formatNumber($number);

        if ($this->isSandbox) {
            return [
                'status'          => true,
                'message'         => '[SANDBOX] OTP requested successfully.',
                'provider_otp_id' => 'SANDBOX-OTP-' . uniqid(),
            ];
        }

        try {
            $payload = [
                'number'        => $formattedNumber,
                'business_name' => $this->provider->business_name ?: config('app.name', 'SHOP NOW BD'),
            ];

            $response = $this->client()->post("{$this->baseUrl}/v3/identity/otp/request", $payload);
            $result = $response->json() ?? [];

            if ($response->successful() && ($result['status'] ?? false || $result['success'] ?? false)) {
                return [
                    'status'          => true,
                    'message'         => $result['message'] ?? 'OTP dispatched.',
                    'provider_otp_id' => $result['otp_id'] ?? $result['data']['otp_id'] ?? null,
                    'data'            => $result,
                ];
            }

            return [
                'status'  => false,
                'message' => $result['message'] ?? 'Could not request Identity OTP.',
                'data'    => $result,
            ];
        } catch (Exception $e) {
            Log::error('OnecodesoftDriver requestIdentityOtp Exception: ' . $e->getMessage());

            return [
                'status'  => false,
                'message' => 'Identity OTP request error: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Onecodesoft Managed Identity OTP Verification
     */
    public function verifyIdentityOtp(string $number, string $code): array
    {
        $formattedNumber = $this->formatNumber($number);

        if ($this->isSandbox) {
            $isMockValid = ($code === '1234' || $code === '1122');
            return [
                'status'  => $isMockValid,
                'message' => $isMockValid ? '[SANDBOX] Verified successfully.' : '[SANDBOX] Invalid OTP code.',
            ];
        }

        try {
            $response = $this->client()->post("{$this->baseUrl}/v3/identity/otp/verify", [
                'number' => $formattedNumber,
                'code'   => trim($code),
            ]);

            $result = $response->json() ?? [];

            if ($response->successful() && ($result['status'] ?? false || $result['verified'] ?? false)) {
                return [
                    'status'  => true,
                    'message' => $result['message'] ?? 'OTP verification confirmed.',
                    'data'    => $result,
                ];
            }

            return [
                'status'  => false,
                'message' => $result['message'] ?? 'Invalid or expired OTP.',
                'data'    => $result,
            ];
        } catch (Exception $e) {
            Log::error('OnecodesoftDriver verifyIdentityOtp Exception: ' . $e->getMessage());

            return [
                'status'  => false,
                'message' => 'OTP verification connection error: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Dispatch Custom Generated OTP Text
     */
    public function sendCustomOtp(string $number, string $message): array
    {
        return $this->sendSingle($number, $message, $this->provider->sender_id);
    }
}