<?php

namespace App\Services\Sms;

use App\Models\CommunicationPreference;
use App\Models\SmsBlacklist;
use App\Models\SmsLog;
use App\Models\SmsProvider;
use App\Models\SmsSetting;
use App\Models\SmsTemplate;
use App\Services\Sms\Contracts\SmsProviderInterface;
use App\Services\Sms\Drivers\OnecodesoftDriver;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Throwable;

class SmsService
{
    protected ?SmsProvider $provider;
    protected SmsProviderInterface $driver;

    public function __construct(?SmsProvider $provider = null)
    {
        if ($provider) {
            $this->provider = $provider;
        } else {
            $query = SmsProvider::where('is_active', true);
            if (Schema::hasColumn('sms_providers', 'is_default')) {
                $query->orderBy('is_default', 'desc');
            }
            $this->provider = $query->first() 
                ?? SmsProvider::where('driver', 'onecodesoft')->first() 
                ?? SmsProvider::first();
        }

        $this->driver = $this->resolveDriver($this->provider);
    }

    /**
     * Resolve provider driver implementation dynamically
     */
    protected function resolveDriver(?SmsProvider $provider): SmsProviderInterface
    {
        $driverName = strtolower((string) ($provider?->driver ?? 'onecodesoft'));

        return match ($driverName) {
            'onecodesoft' => new OnecodesoftDriver($provider),
            default       => new OnecodesoftDriver($provider),
        };
    }

    /**
     * Set driver explicitly on runtime if needed
     */
    public function setProvider(SmsProvider $provider): self
    {
        $this->provider = $provider;
        $this->driver = $this->resolveDriver($provider);

        return $this;
    }

    /**
     * Get the active driver instance
     */
    public function getDriver(): SmsProviderInterface
    {
        return $this->driver;
    }

    /**
     * Clean and format phone numbers to standard 8801XXXXXXXXX format
     */
    public function formatNumber(string $number): string
    {
        $cleaned = preg_replace('/[^0-9]/', '', $number);

        if (str_starts_with($cleaned, '01') && strlen($cleaned) === 11) {
            return '88' . $cleaned;
        }

        if (str_starts_with($cleaned, '1') && strlen($cleaned) === 10) {
            return '880' . $cleaned;
        }

        return $cleaned;
    }

    /**
     * Calculate character count, Unicode detection, and SMS parts
     * GSM: 160 chars for 1 part, 153 chars per part for multi-part
     * Unicode (Bangla/Emojis): 70 chars for 1 part, 67 chars per part for multi-part
     */
    public function analyzeMessage(string $text): array
    {
        $isUnicode = (bool) preg_match('/[^\x20-\x7E\r\n\t]/u', $text);
        $charCount = mb_strlen($text, 'UTF-8');

        if ($isUnicode) {
            $parts = $charCount <= 70 ? 1 : (int) ceil($charCount / 67);
        } else {
            $parts = $charCount <= 160 ? 1 : (int) ceil($charCount / 153);
        }

        return [
            'is_unicode'       => $isUnicode,
            'characters_count' => $charCount,
            'sms_parts'        => max(1, $parts),
        ];
    }

    /**
     * Core method to dispatch single SMS with full safety checks and logging
     */
    public function send(string $number, string $message, string $type = 'transactional', array $options = []): array
    {
        $recipient = $this->formatNumber($number);

        // 1. Check Global System SMS Toggle (allow bypass for test messages)
        $bypassGlobal = !empty($options['bypass_global']);
        if (!$bypassGlobal && !SmsSetting::isEnabled('global_sms_enabled', true)) {
            return $this->logBlocked($recipient, $message, $type, 'Global SMS sending is disabled in settings.', $options);
        }

        // 2. Validate Bangladeshi Phone Format
        if (!preg_match('/^8801[3-9]\d{8}$/', $recipient)) {
            return $this->logBlocked($recipient, $message, $type, 'Invalid recipient mobile number format.', $options);
        }

        // 3. Blacklist Check (Number & IP)
        try {
            if (class_exists(SmsBlacklist::class)) {
                if (method_exists(SmsBlacklist::class, 'isPhoneBlocked') && SmsBlacklist::isPhoneBlocked($recipient)) {
                    return $this->logBlocked($recipient, $message, $type, 'Recipient number is blacklisted.', $options);
                }

                if (!empty($options['ip_address']) && method_exists(SmsBlacklist::class, 'isIpBlocked') && SmsBlacklist::isIpBlocked($options['ip_address'])) {
                    return $this->logBlocked($recipient, $message, $type, 'Request IP address is blacklisted.', $options);
                }

                if (method_exists(SmsBlacklist::class, 'containsSpamWords') && SmsBlacklist::containsSpamWords($message)) {
                    return $this->logBlocked($recipient, $message, $type, 'Message contains blacklisted spam keywords.', $options);
                }
            }
        } catch (Throwable $e) {
            Log::warning('SmsBlacklist check exception bypassed: ' . $e->getMessage());
        }

        // 4. Marketing Permission / Unsubscribe Check
        if ($type === 'marketing') {
            if (!SmsSetting::isEnabled('sms_marketing_enabled', true)) {
                return $this->logBlocked($recipient, $message, $type, 'SMS Marketing is globally disabled.', $options);
            }

            try {
                if (class_exists(CommunicationPreference::class) && method_exists(CommunicationPreference::class, 'canReceiveMarketingSms')) {
                    if (!CommunicationPreference::canReceiveMarketingSms($recipient)) {
                        return $this->logBlocked($recipient, $message, $type, 'Recipient unsubscribed from SMS marketing.', $options);
                    }
                }
            } catch (Throwable $e) {
                Log::warning('CommunicationPreference check bypassed: ' . $e->getMessage());
            }
        }

        // 5. Calculate Message Parts & Estimated Cost
        $metrics = $this->analyzeMessage($message);
        $costPerSms = $this->provider ? (float) $this->provider->price_per_sms : 0.3500;
        $totalCost = $metrics['sms_parts'] * $costPerSms;

        $senderId = $options['sender_id'] ?? $this->provider?->sender_id;

        // 6. Dispatch via OnecodesoftDriver
        $response = $this->driver->sendSingle($recipient, $message, $senderId);
        $isSuccess = (bool) ($response['status'] ?? false);

        // 7. Record SMS Log
        $smsLog = SmsLog::create([
            'recipient'        => $recipient,
            'user_id'          => $options['user_id'] ?? null,
            'order_id'         => $options['order_id'] ?? null,
            'campaign_id'      => $options['campaign_id'] ?? null,
            'sms_type'         => $type,
            'provider'         => $this->provider?->driver ?? 'onecodesoft',
            'sender_id'        => $senderId ?: 'Default',
            'message_id'       => $response['message_id'] ?? null,
            'message_content'  => $message,
            'characters_count' => $metrics['characters_count'],
            'sms_parts'        => $metrics['sms_parts'],
            'cost'             => $totalCost,
            'status'           => $isSuccess ? 'sent' : 'failed',
            'status_code'      => $isSuccess ? '200' : '422',
            'gateway_response' => json_encode($response['data'] ?? $response),
            'is_sandbox'       => (bool) ($this->provider?->sandbox_mode ?? false),
            'sent_at'          => $isSuccess ? Carbon::now() : null,
        ]);

        return [
            'status'     => $isSuccess,
            'message'    => $response['message'] ?? ($isSuccess ? 'Sent successfully' : 'Failed to send SMS'),
            'message_id' => $response['message_id'] ?? null,
            'log_id'     => $smsLog->id,
            'parts'      => $metrics['sms_parts'],
            'cost'       => $totalCost,
        ];
    }

    /**
     * Alias method for send to ensure compatibility across all callers
     */
    public function sendSingle(string $number, string $message, string $type = 'transactional', array $options = []): array
    {
        return $this->send($number, $message, $type, $options);
    }

    /**
     * Send bulk personalized messages via gateway driver
     */
    public function sendBulk(array $messageParameters, ?string $senderId = null): array
    {
        return $this->driver->sendBulk($messageParameters, $senderId);
    }

    /**
     * Dispatch SMS by dynamic template key with automatic variable binding
     */
    public function sendTemplate(string $templateKey, string $number, array $variables = [], array $options = []): array
    {
        $settingKey = "auto_sms_{$templateKey}";
        if (Schema::hasTable('sms_settings')) {
            $setting = SmsSetting::where('key', $settingKey)->first();
            if ($setting && in_array((string) $setting->value, ['0', 'false', 'off'], true)) {
                return [
                    'status'  => false,
                    'message' => "Automatic SMS notification for '{$templateKey}' is disabled in settings.",
                ];
            }
        }

        $template = null;
        if (class_exists(SmsTemplate::class)) {
            if (method_exists(SmsTemplate::class, 'getActive')) {
                $template = SmsTemplate::getActive($templateKey);
            } else {
                $template = SmsTemplate::where('key', $templateKey)->where('is_active', true)->first();
            }
        }

        if (!$template) {
            return [
                'status'  => false,
                'message' => "SMS template '{$templateKey}' not found or inactive.",
            ];
        }

        // Global fallback tags
        $defaultVariables = [
            'store_name'  => config('app.name', 'SHOP NOW BD'),
            'website_url' => url('/'),
        ];
        $allVariables = array_merge($defaultVariables, $variables);

        // Safe message rendering
        if (method_exists($template, 'render')) {
            $message = $template->render($allVariables);
        } else {
            $message = (string) $template->body;
            foreach ($allVariables as $key => $val) {
                $message = str_replace(["{{$key}}", "{{ {$key} }}"], (string) $val, $message);
            }
        }

        $type = match ($template->event_type ?? 'transactional') {
            'auth'      => 'otp',
            'marketing' => 'marketing',
            default     => 'transactional',
        };

        if (!empty($template->sender_id) && empty($options['sender_id'])) {
            $options['sender_id'] = $template->sender_id;
        }

        return $this->send($number, $message, $type, $options);
    }

    /**
     * Helper to log rejected/blocked outgoing attempts
     */
    protected function logBlocked(string $recipient, string $message, string $type, string $reason, array $options): array
    {
        $metrics = $this->analyzeMessage($message);

        $smsLog = SmsLog::create([
            'recipient'        => $recipient,
            'user_id'          => $options['user_id'] ?? null,
            'order_id'         => $options['order_id'] ?? null,
            'campaign_id'      => $options['campaign_id'] ?? null,
            'sms_type'         => $type,
            'provider'         => $this->provider?->driver ?? 'onecodesoft',
            'sender_id'        => $options['sender_id'] ?? 'Default',
            'message_content'  => $message,
            'characters_count' => $metrics['characters_count'],
            'sms_parts'        => $metrics['sms_parts'],
            'cost'             => 0.0000,
            'status'           => 'blocked',
            'status_code'      => 'BLOCKED',
            'gateway_response' => json_encode(['error' => $reason]),
            'is_sandbox'       => (bool) ($this->provider?->sandbox_mode ?? false),
        ]);

        return [
            'status'  => false,
            'message' => $reason,
            'log_id'  => $smsLog->id,
        ];
    }

    /**
     * Query gateway balance and sync provider state
     */
    public function syncBalance(): array
    {
        return $this->driver->checkBalance();
    }

    /**
     * Alias for syncBalance
     */
    public function checkBalance(): array
    {
        return $this->syncBalance();
    }

    /**
     * Check delivery status report (DLR) for sent message ID
     */
    public function checkDeliveryStatus(string $messageId): array
    {
        return $this->driver->checkDeliveryStatus($messageId);
    }

    /**
     * Managed Identity OTP Request
     */
    public function requestIdentityOtp(string $number): array
    {
        return $this->driver->requestIdentityOtp($number);
    }

    /**
     * Managed Identity OTP Verification
     */
    public function verifyIdentityOtp(string $number, string $code): array
    {
        return $this->driver->verifyIdentityOtp($number, $code);
    }

    /**
     * Send custom generated OTP
     */
    public function sendCustomOtp(string $number, string $message): array
    {
        return $this->driver->sendCustomOtp($number, $message);
    }
}